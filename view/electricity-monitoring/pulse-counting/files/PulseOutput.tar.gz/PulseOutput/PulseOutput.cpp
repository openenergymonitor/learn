/*
  PulseOutput.cpp - Library for openenergymonitor
  Created by Trystan Lea, April 27 2010
  GNU General Public Licence: http://openenergymonitor.org/emon/node/4
*/

#include "WProgram.h"
#include "PulseOutput.h"

//Set sinput pin and pulses per kwh
PulseOutput::PulseOutput(int _inPin,int _ppkwh)
{
  inPin = _inPin;
  ppkwh = _ppkwh;
}

//Set the digital pin to input
void PulseOutput::init()
{
  pinMode(inPin, INPUT); 
}

//read digtal input, store value in val and lval.
//called m so that it doesnt take up to much space in the sketch
//let me know if this is annoying :)
void PulseOutput::m()
{
  lval = val;
  val = digitalRead(inPin);
}

int PulseOutput::pulse(unsigned long time)
{
  int pulseDetected=0;

  //On falling edge of pulse.
  if (lval==1 && val==0) 
  { 
    //used to measure time between pulses.
    pulseTime = time;
    //pulseCounter
    pulseCount++;                
  
    //Calculate power
    power = (3600000000.0 / (pulseTime - lastTime))/ppkwh;
    lastTime = pulseTime;
  
    //Find kwh elapsed
    kwh = 1.0*pulseCount/ppkwh;

    pulseDetected = 1;
  }
  else
  { pulseDetected = 0; }

   return pulseDetected;
}

