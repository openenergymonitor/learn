/*
  PulseOutput.h - Library for openenergymonitor
  Created by Trystan Lea, April 27 2010
  GNU General Public Licence: http://openenergymonitor.org/emon/node/4

  Reads pulse output from kwh meters.
  Uses continuous sampling of digitalinputs method which is not as nice as the interrupt method
  but allows reading of more than 2 kwh meters.
*/

#ifndef PulseOutput_h
#define PulseOutput_h

#include "WProgram.h"

class PulseOutput
{
  public:

  //Set sinput pin and pulses per kwh
  PulseOutput(int _inPin,int _ppkwh);

  //Used to detect pulse
  int lval,val;

  //Number of pulses, used to measure energy.
  long pulseCount;   
  //Used to measure power.
  unsigned long pulseTime,lastTime;
  //power and energy
  double power, kwh;

  //Input pin and pulse per kwh
  int inPin;
  int ppkwh;

  //Sets the digital pin to input
  void init();
  //read digtal input, store value in val and lval.
  //called m so that it doesnt take up to much space in the sketch
  //let me know if this is annoying :)
  void m();
  //detects if a pulse occured and
  int pulse(unsigned long time);

  private:


};

#endif
