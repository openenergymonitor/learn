﻿
<?php
/*

This file has the basic data that the SMAwebBox_dataExtractor needs to access to the database

*/

const DB_SERVER = "localhost";
const DB_NAME = "cat_backup";
const DB_USER = "pushFTP";
const DB_PASSWORD = "pushFTP";

?>