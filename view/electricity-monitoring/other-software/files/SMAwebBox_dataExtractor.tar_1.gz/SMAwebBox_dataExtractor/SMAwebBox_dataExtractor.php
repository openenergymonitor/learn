
<?php
/*
 SMAwebBox_dataExtractor
Version: 1.0
Last revision 05 October 2010
Licence: GNU GPL
By Carlos Alonso Gabizón

Please send any bug, feedback, etc. to cagabi@lapiluka.org

*/



	require_once('pclzip.lib.php');	
	require_once('SMAwebBox_dataExtractor.conf.php');	
	
	function move_file($origin, $destination){
		global $log_file_handle;		
		if(copy($origin, $destination)){
    	    fwrite($log_file_handle, " - - " . " copied to " . $destination);
    	    if(unlink($origin)){
				fwrite($log_file_handle, " - - " . "original file deleted\r\n");
				return true;
			}
			else{
				fwrite($log_file_handle, " - - " . "ERROR: " . "original file could not be deleted\r\n");
				return false;
			}
    	}
	    else{
    		fwrite($log_file_handle, " - - " . "ERROR: " . "could not be copied to " . $destination . "\r\n");
    		return false;
    	 }							
	}
	

	function morefiles_indir($origin){
		global $log_file_handle;		
		if (!$dir_handle = opendir($origin)){
			fwrite($log_file_handle, " - - " . "ERROR in the function 'morefile_indir()'");
			exit;
		}
		$filename = readdir($dir_handle); 
		while($filename !== false){
			if(is_file($origin . "\\" . $filename)){
				fwrite($log_file_handle, " - - " . "there are more files in the directory\r\n");				
				return true;
			}
			$filename = readdir($dir_handle);
		}
		fwrite($log_file_handle, " - - " . "no more files in the directory, the extraction has finished\r\n");
		return false;
	}		
    	    	
    	    	
	function extract_zipfile($origin, $destiny){
		global $log_file_handle;
		$zip_archive = new PclZip($origin);
		$extracted_file = $zip_archive->extract(PCLZIP_OPT_PATH, $destiny);					
		if($extracted_file == 0) {
			fwrite($log_file_handle, " - - " . 'ERROR unzipping ' . $filename . ': ' . $zip_archive->errorInfo(true));
			return false;
		}
		else{
			fwrite($log_file_handle, " - - " . ' unzipped');
			return true;    			
		}        				
	}
	
	function delete_file($origin){
		global $log_file_handle;		
		if(unlink($origin)){
  			fwrite($log_file_handle, " - - " . " deleted\r\n");
			return true;  		
  		}
  		else{
  			fwrite($log_file_handle, " - - " . "ERROR: " . "couldn´t be deleted\r\n");
  			return false;
  		}
     }
     
     
     function extract_xmlfile($origin, $db_connection){
		global $log_file_handle;		
		$xml_file = simplexml_load_file($origin);
		if($xml_file->MeanPublic[0]){ //if there are MeanPublic elements in the file, it means that $xml_file contents data			
			$i = 0;			
			while($xml_file->MeanPublic[$i]){			
				//$fields_list is a string which contents the the table´s fields for the sql query
				//$values_list is a string which contents the new register´s values for the sql query
				$key = split(":", $xml_file->MeanPublic[$i]->Key);	//the key element has the next format: devicetype:serialnumber:parameter, we split it so that we can use each part of it
				$table_name = $key[1]; //the table name has the following format: serialnumber
				$fields_list = "`TimeStamp`";
				$values_list = "'" . str_replace('T', ' ', $xml_file->MeanPublic[$i]->TimeStamp). "'";//the time element has the following format dateTtime, we take the "T" off and write a white space for compatibility with sql 
				do{
					$key = split(":", $xml_file->MeanPublic[$i]->Key);			
					$field = $key[2];				
					$fields_list .= ", `" . $key[2] . "`";
					$values_list .= ", " . $xml_file->MeanPublic[$i]->Mean;
					$i++;
					$key = split(":", $xml_file->MeanPublic[$i]->Key);
				}while($table_name == $key[1]); //we check that the next element corresponds still to the same device, if it doesn´t we escape the from loop
				$sql_query = 'INSERT INTO `' . $table_name . '` (' . $fields_list . ') VALUES (' .$values_list .')'; 			
				fwrite($log_file_handle, " - - " . "generating sql query for " . $table_name . ' - ' . $xml_file->MeanPublic[$i-1]->TimeStamp);			
				$resultado = $db_connection->query($sql_query);
				if (!$resultado){		
					fwrite($log_file_handle, " - - " . "ERROR: problems with the query: " . $db_connection->error);
					fwrite($log_file_handle, "\r\n" . $sql_query . "\r\n");					
					return false;			
				}
				else{
					fwrite($log_file_handle, " - - " . "REGISTER successfully inserted");
				}		
			}
		}
		else if($xml_file->Event[0]){//if there are Event elements in the file, it means that $xml_file contents log information
			$i = 0;			
			while($xml_file->Event[$i]){
				$sql_query = "INSERT INTO `log_webbox` (`Key`,`EventType`,`AccessLevel`,
				`Category`,`Device`,`MessageCode`,`MessageArgs`,`Message`) VALUES ('" 
				. str_replace('T', ' ', $xml_file->Event[0]->Key) . "', '"
				. $xml_file->Event[$i]->EventType . "', '" 
				. $xml_file->Event[$i]->AccessLevel	. "', '" . $xml_file->Event[$i]->Category . "', '"
				. $xml_file->Event[$i]->Device	. "', '" . $xml_file->Event[$i]->MessageCode . "', '" 
				. $db_connection->real_escape_string($xml_file->Event[$i]->MessageArgs) //"real_escape_string" for avoiding a bug; it escapes special characters in a string for use in a SQL statement. There has been situations when this argument was invalid fo having "Can´t"
				."', '" . $xml_file->Event[$i]->Message 
				. "')";
				fwrite($log_file_handle, " - - " . "generating sql query for 'log_webbox' - " . $xml_file->Event[$i]->Key);
				//$sql_query = $db_connection->real_escape_string($sql_query);			
				$resultado = $db_connection->query($sql_query);
				if (!$resultado){		
					fwrite($log_file_handle, " - - " . "ERROR: problems with the query: " . $db_connection->error . " - - " . "sql_query: " . $sql_query);
					return false;			
				}
				else{
					fwrite($log_file_handle, " - - " . "REGISTER successfully inserted");
				}
				$i++;					
			}
		}
		else{
			fwrite($log_file_handle, " - - " . "This file is not a 'Mean.' neither 'Log.' file, it was not possible to extract any data");
			return false;		
		}
 		fwrite($log_file_handle, " - - " . "end of the .xml file");
		return true;
     }	
     
     
     /*----------------------------------------------------------*/
	
	/*When this application is thrown using CLI (Command Line Interface), the working directory isn´t where the application is. The working directory is where php-win.exe is. 
	When we use CLI we need to change the working directory to the one where SMAwebBox_dataExtractor.php is
	*/
	chdir(__DIR__);	
	
	//we open the log file, if it doesn´t exist it is created
	$log_file_handle = fopen(getcwd() . "\\log\\" . "log_" . date('Y-m-d') . ".txt", a);

	//we write in the log file that the applicatoin has been launched
	fwrite($log_file_handle,date("[d/M/Y-H:i:s]") . " - - " . "PushFTP application launched\r\n");	
		 
	//we open the directory where the PushFTP function is uploading the files	
	if ($pushFTP_handle = opendir("pushFTP_files")){
		fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . "'pushFTP_files' directory opened\r\n");
	}
	else{
		fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . "ERROR opening 'pushFTP_files' directory\r\n");
	}
	
	//we connect to the database
	$db_connection = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
	if ($db_connection->connect_error) {
    		fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . "ERROR: could not connect to 'cat_backup' database -- " . mysqli_connect_errno() . mysqli_connect_error() . "\r\n");
	}
	else{
		fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . "conected to 'cat_backup' database, user pushFTP\r\n");
	}

	//we start reading the files in the directory and deal with them	
	$process_finished = false;
	while(!$process_finished){
		$filename = readdir($pushFTP_handle);//we read the next file in the directory, if it´s the first time we read the first file
		fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . $filename . " readed");
		if ($filename === false){//if we are pointing to the end of the directory
			fwrite($log_file_handle, " - - " . "EOF");
			if(morefiles_indir(getcwd() . "\\pushFTP_files")){//we check if there are more files in the directory, if so we point to the beginning of the directory, if not we have finished
				rewinddir($pushFTP_handle);
			}			
			else{
				$process_finished = true;
			}
		}		
		else if (is_dir(getcwd() . "\\pushFTP_files\\" . $filename)){//if we are not pointing to the end of the directory but pointing to a directory we don´t do anything
			fwrite($log_file_handle, " - - " . "is a directory\r\n");		
		}		
		else if(is_file(getcwd() . "\\pushFTP_files\\" . $filename)){//if we are pointing to a file	we check if it is a .zip, .xml or something different
			switch (substr($filename, -4)) {
				case ".zip":
        				fwrite($log_file_handle, " - - " . "is a .zip file");
        				if(!extract_zipfile(getcwd() . "\\pushFTP_files\\" . $filename, getcwd() . "\\pushFTP_files\\")){//if there is a probelm unzipping the file we moved it to the unextracted_files directory
        					if(!move_file(getcwd() . "\\pushFTP_files\\" . $filename, getcwd() . "\\unextractedFILES\\" . $filename)){
							$process_finished = true;//if we can´t move/delete the file we exit the program, otherwise we will be stack in an eternal loop. The application ends when there are not more files in the directory; if we can´t move/delete the files from the directory (and we don´t force the program to finish) there will always be files in there and the program would never end
							}
						}
						else{//if we have succeded unzipping the file, we check if it is the original one uploaded from the webBox (it start wirh 'wb'), in this case we move it to the zip_files directory for keeping the as redundant information (just in case), otherwise we just delete it
							if ($filename[0] == 'w' && $filename[1] == 'b'){						
								if(!move_file(getcwd() . "\\pushFTP_files\\" . $filename, getcwd() . "\\zipFILES\\" . $filename)){
									$process_finished = true;//if we can´t move/delete the file we exit the program, otherwise we will be stack in an eternal loop. The application ends when there are not more files in the directory; if we can´t move/delete the files from the directory (and we don´t force the program to finish) there will always be files in there and the program would never end
								}
							}
							else{
								if(!delete_file(getcwd() . "\\pushFTP_files\\" . $filename)){
									$process_finished = true;//if we can´t move/delete the file we exit the program, otherwise we will be stack in an eternal loop. The application ends when there are not more files in the directory; if we can´t move/delete the files from the directory (and we don´t force the program to finish) there will always be files in there and the program would never end
								}
							}
						}			
	        			break;
    				case ".xml":
    	    			fwrite($log_file_handle, " - - " . " is a .xml file");
    	    			$process_finished = false;
    	    			if(!extract_xmlfile(getcwd() . "\\pushFTP_files\\" . $filename, $db_connection)){//if there are problems extracting/inserting the content of the xml file, we move it to the unextracted_files directory, otherwise we delete it
							if(!move_file(getcwd() . "\\pushFTP_files\\" . $filename, getcwd() . "\\unextractedFILES\\" . $filename)){
								$process_finished = true;//if we can´t move/delete the file we exit the program, otherwise we will be stack in an eternal loop. The application ends when there are not more files in the directory; if we can´t move/delete the files from the directory (and we don´t force the program to finish) there will always be files in there and the program would never end
							}
						}
						else{
							if(!delete_file(getcwd() . "\\pushFTP_files\\" . $filename)){
								$process_finished = true;//if we can´t move/delete the file we exit the program, otherwise we will be stack in an eternal loop. The application ends when there are not more files in the directory; if we can´t move/delete the files from the directory (and we don´t force the program to finish) there will always be files in there and the program would never end
							}
						}			
	        			break;

	    			default:// if the file isn´t a zip or xml file we move it to the unextracted_files directory
		        		fwrite($log_file_handle, " - - " . " is not a directory, a .xml / .zip file or EOF");
						if(!move_file(getcwd() . "\\pushFTP_files\\" . $filename, getcwd() . "\\unextractedFILES\\" . $filename)){
							$process_finished = true;//if we can´t move/delete the file we exit the program, otherwise we will be stack in an eternal loop. The application ends when there are not more files in the directory; if we can´t move/delete the files from the directory (and we don´t force the program to finish) there will always be files in there and the program would never end
						}
						break;
			}
		}
		

	}	

	closedir($pushFTP_handle); // we close the "connection" to the directory
	fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . "pushFTP directory closed\r\n");
	
	if($db_connection->close()){//we close the database connection
		fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . "Connection to database closed\r\n"); 
	}
	else
	{
		fwrite($log_file_handle, date("[d/M/Y-H:i:s]") . " - - " . "ERROR: the connection to the database could not be closed\r\n"); 
	}
	
	fclose($log_file_handle); //we close the log file
	
?> 

